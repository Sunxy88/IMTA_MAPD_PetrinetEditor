# Description
This repository is the for the *fil rouge* of the course MAPD.

# TODO list
* Write test cases
* Test
* Fix bugs