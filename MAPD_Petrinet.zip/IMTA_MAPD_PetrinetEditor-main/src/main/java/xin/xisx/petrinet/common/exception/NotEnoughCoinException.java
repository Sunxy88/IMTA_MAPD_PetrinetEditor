package xin.xisx.petrinet.common.exception;

public class NotEnoughCoinException extends RuntimeException {
}
