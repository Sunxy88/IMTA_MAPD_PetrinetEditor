package xin.xisx.petrinet.common.exception;

/**
 * @author Xi Song
 */
public class ItemAlreadyExistsException extends RuntimeException {

    public ItemAlreadyExistsException(String msg) {
        super(msg);
    }
}
