package xin.xisx.petrinet.common.exception;

public class IllegalStatusException extends RuntimeException {
    public IllegalStatusException() {
        super("Something went wrong like NullPointerException");
    }
}
